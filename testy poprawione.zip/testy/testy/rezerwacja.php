<?php
echo"Dodano Rezerwacje do Bazy"

?>